
#print("Python has three numeric types: int, float, and comple
myvalue= 1
#print(myvalue)
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
myvalue= 3.14
#print(myvalue)
#print(type(myvalue))
#print(str(myvalue) + "is of the data type" + str(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
myvalue=5j
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
myvalue=True
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
mystring = 'this is a string'
print(mystring)
print(type(mystring))
print(mystring + " is of the data type " + str(type(mystring)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
#print(thirdString)
name = input("What is your name? ")
#print(name)
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,color,animal))
