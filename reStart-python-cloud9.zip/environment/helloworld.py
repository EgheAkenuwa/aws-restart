python --version


